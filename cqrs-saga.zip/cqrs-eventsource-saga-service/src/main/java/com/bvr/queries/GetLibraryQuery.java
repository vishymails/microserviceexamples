package com.bvr.queries;

public class GetLibraryQuery {

	
	private final Integer libaryId;

	public GetLibraryQuery(Integer libaryId) {
		super();
		this.libaryId = libaryId;
	}

	public Integer getLibaryId() {
		return libaryId;
	}
}
