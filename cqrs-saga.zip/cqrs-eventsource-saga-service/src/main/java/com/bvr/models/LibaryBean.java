package com.bvr.models;

public class LibaryBean {

	private int libraryId;
	private String name;
	
	
	public LibaryBean() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getLibraryId() {
		return libraryId;
	}


	public void setLibraryId(int libraryId) {
		this.libraryId = libraryId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}
	
	
}
