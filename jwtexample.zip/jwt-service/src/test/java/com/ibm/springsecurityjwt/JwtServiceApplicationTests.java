package com.ibm.springsecurityjwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
